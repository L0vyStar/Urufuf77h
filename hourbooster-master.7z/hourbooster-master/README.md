## Introduction
Simple script to iddle time on steam games without any additional costs. 

## Features
- Steam Guard Support (No Shared Secret Required)
- Custom In-Game Title 
- Up to 32 Games per account
- Unlimited Accounts at once instance

## Getting started
- Install latest version of NodeJS from official website.
- Open `install.bat` and wait until it installs all required modules.
- Open the `config.json` and fill all required fields.
- Then just run `node bot.js` or open `start.bat` to launch the script.

