const clock = true;

module.exports.clock = clock;
