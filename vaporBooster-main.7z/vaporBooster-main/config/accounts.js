var configsArray = [];
var config;


config = {};
config.username = 'iAtYywjPr';
config.password = '1QNTgrogtRVdb88';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'hfW5ckr8Z';
config.password = 'TlFZ9qscdYAI2R3';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'ycuoAozSc';
config.password = 'UFg5lnbbIRgU60';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'RHyRQZaFPEr5';
config.password = 'd1OgNMwhitc4l';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'hQXU1Qy86k18';
config.password = 'vVj86HeDQ2Wzqt0';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'osgFIFkfxvTL';
config.password = 'cPcnVOkrEZYAJ';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'xbsyfjN1wy';
config.password = 'blo4iIpjVuwlxTv';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'cZwPKWOq9i';
config.password = 'L9q61FwshNP12';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = '4llabNcw7c8';
config.password = '2Pl2JoBrfqpIb';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'nrW0BpPz7';
config.password = 'XRUk1Tot9GKd7r';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'vhcr952zP0Oi';
config.password = 'r7h0G0ZLAwbryU';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'C3vTrhcx2';
config.password = '3EtG9gCeGkD6oW';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'fCrU24IZDR3T';
config.password = 'yMrt514gxx0Vnxt';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = '1OJTYc2znOp';
config.password = 'GfAnpZYCM0Oll';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = '019ePjEOy4tk';
config.password = 'cAkuqJAi7XWAHqr';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'MRgT2sWZK';
config.password = 'C3qjeGHQqLL7vD';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'Dwysu5FjLN';
config.password = '7JAcQn6Pqaf6X1H';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'Ev3cuxNEsFnD';
config.password = 'f4M8aA9dBYSH5';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

config = {};
config.username = 'bh4or2jRCkp';
config.password = 'JHW5ifhzDGqvbS';
config.sharedSecret = '';
config.enableStatus = true;
config.gamesAndStatus = [1172470, 730, 440, 570, 578080, 236390];
config.replyMessage = '';
config.receiveMessages = false;
config.saveMessages = false;
configsArray.push(config);

module.exports = configsArray;
