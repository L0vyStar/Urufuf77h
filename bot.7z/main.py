# -*- coding: utf-8 -*-

from telebot import TeleBot
from telebot import types
import telebot
import emoji
import re
import random
import time
import datetime
import pytz
import logging


logger = logging.getLogger(__name__)
logger.setLevel(logging.ERROR)

file_handler = logging.FileHandler('log.txt')
file_handler.setLevel(logging.ERROR)

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


try:
    bot = TeleBot('7294287855:AAFPRU6VBaKvkTsKrcZ6t5Ej9NdNjZpiN44')

    sticker_packs = {
        'KuzyaKrutoi': [
            'CAACAgIAAxkBAAOaZu3WrIokDOv19Fw8wIFe6h9hkVQAAmhLAAIVWjBIKMGJKrUzol82BA',
            'CAACAgIAAyEFAASPV1kxAANQZu3XsBi7znqMMEe49J6xJH1q-IMAAqxLAAJ7UTBI9Lngqv9wopE2BA',
            'CAACAgIAAyEFAASPV1kxAANSZu3XwQp9DmL8aZSkOtWXtGRUDFEAArJQAAJt55BIL6fZK5yMt2I2BA',
            'CAACAgIAAyEFAASPV1kxAANUZu3XyZqJGBeLCPBojs-NpyPcr0sAAihNAALmmZlINvuotLgAAYFQNgQ',
            'CAACAgIAAyEFAASPV1kxAANWZu3X0aYrmDi8yYYWfvVtM6-L6QsAAp5PAALmW5FIlbnOZt5G56I2BA',
            'CAACAgIAAyEFAASPV1kxAANqZu3YGqcRaso8jaDjsSNJaWe9UjsAAjBKAAI6hJBI1E_8zDjgtU02BA',
            'CAACAgIAAyEFAASPV1kxAANsZu3YLZJD1dtRzKkOxaN3PL-yoaQAAiFTAAKEO5BIYkx8fBX64Gc2BA',
            'CAACAgIAAyEFAASPV1kxAANuZu3YNvAjmfyk1co_2AFiyOsnlQgAAmRMAAJQ6JhIzGYPPm-ZrLM2BA',
            'CAACAgIAAyEFAASPV1kxAANwZu3YP64eXaja5sfPTjb_a3tmSlMAAixQAAKfzZlImVzaVdWHXuw2BA',
            'CAACAgIAAyEFAASPV1kxAANyZu3YRlhb9_n2yUs0MNHRTnY41JsAAnxTAAKVwJBIQ81bEXI_iAc2BA',
            'CAACAgIAAyEFAASPV1kxAAN0Zu3YTu5U3hos0HLRYETTVQ99_IoAAqNMAAK6R5hIhciWvS-RL9w2BA',
            'CAACAgIAAyEFAASPV1kxAAN2Zu3YiGrTwxCBb6PapNiuE1zjLJAAAnhNAAI-J5lIfxeIzcKj2JE2BA',
            'CAACAgIAAyEFAASPV1kxAAN4Zu3YnR28YGoXaotkrBYaTIjIOTsAAqVPAAK_7ZlI3bxFeSq4KBs2BA',
            'CAACAgIAAyEFAASPV1kxAAN6Zu3YpdWVW1AT8GnkzLr2KpjuuYsAAq5XAAKNXplIhJtmt6q7Z3M2BA',
            'CAACAgIAAyEFAASPV1kxAAN8Zu3Yrf9_XLDzFm9zpYHXVm8hht0AAqBMAAJ2DpBICcMr5Ert4AI2BA',
            'CAACAgIAAyEFAASPV1kxAAN-Zu3YxtoJDd4JjIN-6tSJ0XobZ3oAAhdTAAIMqpBIZ_ASQENas1s2BA',
            'CAACAgIAAyEFAASPV1kxAAOAZu3Y273eeV5PKvRw5q5hjcA5cXcAAk1MAAIdL5BI-8-kQdEWVCU2BA',
            'CAACAgIAAyEFAASPV1kxAAOCZu3Y4jvt1dLfPEHYu7hzyf0o9vIAAuFIAALn4JFIFC2QULhQ6e42BA',
            'CAACAgIAAyEFAASPV1kxAAOEZu3Y7bd9KlMM98RX6XqIZwayS5sAAo9RAAJVT5lIG7_U7gS_KoY2BA',
            'CAACAgIAAyEFAASPV1kxAAOGZu3Y9DA_ofqVjQfxdC0kRQ4GyfcAAh5OAAKc-pFIvqjS9S6HseE2BA',
            'CAACAgIAAyEFAASPV1kxAAOIZu3Y_uOdrhJICCzJoaMYzZhbidwAAslTAAJENZBIr7uBCzgMPQY2BA',
            'CAACAgIAAyEFAASPV1kxAAOKZu3ZBI5ad93xmzI3xNxLFHDfR0MAAhxNAAKG8ZhI-ppnsy4bYFk2BA',
            'CAACAgIAAyEFAASPV1kxAAOMZu3ZDV7P-qaS316FZsJBAyUP4RQAAgFWAAL36qhIWw3okUq5HjU2BA',
            'CAACAgIAAyEFAASPV1kxAAOOZu3ZF566dA93lGysEYyGXxaNljYAAv5UAAJbpalIGiOWDn-Sz2o2BA',
            'CAACAgIAAyEFAASPV1kxAAOQZu3ZIM3PEycOJ72W-aG-oXkJ_doAAiFVAAIQm7BIMDfxXNmLLfc2BA',
            'CAACAgIAAyEFAASPV1kxAAOSZu3ZKPZX3TJIcCAtvlXf1cil1i4AAkpVAAIgSLBIn8kj-pTZQuc2BA',
            'CAACAgIAAyEFAASPV1kxAAOUZu3ZNUcq-Yte6r-JkHBLKVP8-1cAAipRAAI0A6hIjOQc241qedM2BA',
            'CAACAgIAAyEFAASPV1kxAAOWZu3ZO0PIbEWUDlEW0WewzZbXB90AAthYAAIYGalISuzjcASXmVk2BA',
            'CAACAgIAAyEFAASPV1kxAAOYZu3ZRYbaXq44xjmZgmk0GirgzEkAArZeAAK7VbFI3vsQNhjdPfM2BA',
            'CAACAgIAAyEFAASPV1kxAAOaZu3ZTTz4v99XJ3ZwZi23AtZ8yxIAAilRAAIf6LFI_xHiwOSXNzg2BA',
            'CAACAgIAAyEFAASPV1kxAAOcZu3ZV1SP4aLJdiX9hyV9XYE59PwAAnFTAAIkRKlIcEWaNqXMdGU2BA',
            'CAACAgIAAyEFAASPV1kxAAOeZu3ZXb6sB9Q7VkIYqvbV90xzw58AAjZZAAIS8qlIGaqv8-jmu642BA',
            'CAACAgIAAyEFAASPV1kxAAOgZu3ZZT3nS3axxe2dY7IKM2zIXowAAglXAAKAFKhIZeeSFbUWogc2BA',
            'CAACAgIAAyEFAASPV1kxAAOiZu3ZbGOO1G2YbxS7BANzQyY8aLAAArtWAAJhd6hI7kZFlGWwJgg2BA',
            'CAACAgIAAyEFAASPV1kxAAOkZu3Zc9QLmY9H6yYi2dNvX5SyK1AAAi5TAAK9jLFIv1SgvouJt342BA',
            'CAACAgIAAyEFAASPV1kxAAOmZu3ZiUKUjehFqRHRb53M3_U2O6YAAlhZAALs4qhI2Yd94Bp1CwE2BA',
            'CAACAgIAAyEFAASPV1kxAAOoZu3Zj3wv_I7P-i-gFdiwPIafAAE6AAKmWAACo86oSMTPx5TKyaI6NgQ',
            'CAACAgIAAyEFAASPV1kxAAOqZu3Zl4wXU3sS97QsWqTNtc0Li2QAAmJMAAKdUqhIcJXNSHeYqQo2BA',
            'CAACAgIAAyEFAASPV1kxAAOsZu3ZnuCAzzKbUNBq2-7ZER-X3RIAAn5OAAJ9TLFILPlY1I-L-cg2BA',
            'CAACAgIAAyEFAASPV1kxAAOuZu3Zpc_Oo_zeF5SUk3zdCSq2OCEAAtdPAAJ08shIq2cTGkFpP4U2BA',
            'CAACAgIAAyEFAASPV1kxAAOwZu3ZrBJegdD50G9sbp4ftmUAAUqbAAJsWQACQw3JSJZotbP1q_OzNgQ',
            'CAACAgIAAyEFAASPV1kxAAOyZu3Zs3lb4_S6ukv5Wzl466KYsQ8AAgNLAAJukMlIzp_X0wb5zgI2BA',
            'CAACAgIAAyEFAASPV1kxAAO0Zu3ZurXeGng_aVARJ_TfomX6ZMEAAkZQAALhc8hIJB8D_ShrdsI2BA',
            'CAACAgIAAyEFAASPV1kxAAO2Zu3ZxCEoe9MKmaVb9KN3Nv8vZ6UAAltGAAIbeNBIa99FSu99Spk2BA',
            'CAACAgIAAyEFAASPV1kxAAO4Zu3ZymamfYH_L0GxCUG46c-WZ28AAsxTAALypslI-Xeiw-rSPcw2BA',
            'CAACAgIAAyEFAASPV1kxAAO6Zu3Z0hZ7KZ586emE04GcVMi73_sAAthNAAJFxshIkZufi9jMN1A2BA',
            'CAACAgIAAyEFAASPV1kxAAO8Zu3Z3iKH9hNE-1giUi4eA3O6pl0AAjZSAALk-8lIqUy0AqKa0VI2BA',
            'CAACAgIAAyEFAASPV1kxAAO-Zu3Z8THFpTpQb5WtD7TkKP74T0sAAm9QAAKW3clIw_1BCnSAoOY2BA',
            'CAACAgIAAyEFAASPV1kxAAPAZu3Z-ilLyzhwoqF0FobcRY7Uhp0AAo9RAAJ50slIAZYhb3_NSJ42BA',
            'CAACAgIAAyEFAASPV1kxAAPCZu3aBepxmIZzfvUiS_pezeAOnksAAuZPAAJ8_8lIDHcNqT7qJyQ2BA',
            'CAACAgIAAyEFAASPV1kxAAPEZu3aEucQHWe6SZaJ9YIRsOEQlN8AAhVTAAKlBshITrVNnIXYddE2BA',
            'CAACAgIAAyEFAASPV1kxAAPGZu3aGXtC3PJsFQOokCLpTyCd8moAAtljAAI1SfFJUwKOymgdJwY2BA',
            'CAACAgIAAyEFAASPV1kxAAPIZu3aIj7lP0afHUp4Izy9dAPuys8AAoxVAAIkUvhJyU0b4Hx_40Y2BA',
            'CAACAgIAAyEFAASPV1kxAAPKZu3aKN-ckmFjpdXxCVp4-jn9fJgAAo1SAAIf6fBJGkbdidtqELk2BA',
            'CAACAgIAAyEFAASPV1kxAAPMZu3aL_VAx-wjkGXMIbpnyyaq-u0AAldcAAJYzfhJ79kYmjKU_DA2BA',
            'CAACAgIAAyEFAASPV1kxAAPOZu3aNZE2Uo_kaGghFqY2B8YuJTIAAjtaAAKUVfBJh10oJJHhPsU2BA',
            'CAACAgIAAyEFAASPV1kxAAPQZu3aPNtHmIzkMs_ffeC4pbYF2lsAAmpSAAIYLPhJazRORhHuJJU2BA',
            'CAACAgIAAyEFAASPV1kxAAPSZu3aQ-3DHew1syLAjHgfgEdllmwAArNYAAINEvFJI-ua7wW-_302BA',
            'CAACAgIAAyEFAASPV1kxAAPUZu3aSpaG8rBZ-5fOF9LiVznwvo0AApxWAAKhF_lJY33GpWNGR3Y2BA',
            'CAACAgIAAyEFAASPV1kxAAPWZu3aUjQR6g2qPE7mC9icElPtAzQAAoZxAAJ6L_hJqig_5wz7CB82BA',
            'CAACAgIAAyEFAASPV1kxAAPYZu3aWSLrY_qcfRvvMSD1RnVaZZcAAkFZAAJtcfFJR2lJTGcblzA2BA',
            'CAACAgIAAyEFAASPV1kxAAPaZu3aYCI3Hyg0mmZt1cFlMd897WUAAgZWAAKREfBJS6JGtE6sD_w2BA',
            'CAACAgIAAyEFAASPV1kxAAPcZu3aZ_GvGbmzK9Wpqw1R6C_yBEgAAhRMAAKOxvhJROISrvQpbtM2BA',
            'CAACAgIAAyEFAASPV1kxAAPeZu3ab_Gj5rf1a99HjbbdqFu8Ul4AAllYAAKdUvBJTx2xpY2y1iY2BA',
            'CAACAgIAAyEFAASPV1kxAAPgZu3adq9KMos06778P08mUIlC3uoAAuRWAAK9-PFJ_A3ELhr6H5M2BA',
            'CAACAgIAAyEFAASPV1kxAAPiZu3afmPIAAFTepIFgsm15BRMnrl3AAJwWgACU2PwSUQ_bIl82bhENgQ',
            'CAACAgIAAyEFAASPV1kxAAPkZu3ahMJ2PLu8L-0MBl8FOBcFag0AAqhKAAKGFFlKKSbTjr6m-Wg2BA',
            'CAACAgIAAyEFAASPV1kxAAPmZu3aizK9TAABRckg6dzGRNO_wOzDAAJ3VgACdoNYSmysyRAO6VNjNgQ',
            'CAACAgIAAyEFAASPV1kxAAPoZu3ak1wyRQrd1n4c8te48XDsAAEHAAKYWAACDdpZSntXhN7mKIgFNgQ',
            'CAACAgIAAyEFAASPV1kxAAPqZu3amVKTJ_Vz2Y7ZTnewhE_YzIcAAhhNAAIpvlhK5qdUTHN4y9I2BA',
            'CAACAgIAAyEFAASPV1kxAAPsZu3aoKq8toSnD-lSOqOsIaOQ6nAAAtZRAAJ_S1lKfZbY_AABKLwXNgQ',
            'CAACAgIAAyEFAASPV1kxAAPuZu3aqV2hiWszSF1PhYzCzJsAAZUSAAJ8UwACEuNYSgE6OFb3Mcg3NgQ',
            'CAACAgIAAyEFAASPV1kxAAPwZu3ar2uP9xw-2CkSaRSxiAtDFxYAAixoAAK8jVhKvIMlxeVZSxQ2BA',
            'CAACAgIAAyEFAASPV1kxAAPyZu3atdn_LFH9_Y09aXeXWgwfh9sAAsRPAAJreFhKsG69C6IPgH42BA',
            'CAACAgIAAyEFAASPV1kxAAP0Zu3aujHVz9DTSnNf2dhY_6_ZtegAAhNOAAKMLVhKFA_F4aNevAg2BA',
            'CAACAgIAAyEFAASPV1kxAAP2Zu3awEwM0NU7UCUafA_5Z65OX0QAAktTAAKD5RlLevo-3Hyop-A2BA',
        ],
        'BoSinnKuzya': [
            'CAACAgIAAyEFAASPV1kxAAIBE2bt2xfE8JvM9sp9XrJRa4lPMOTCAAL0TgACGvzJSDof4Y3hWBLrNgQ',
            'CAACAgIAAyEFAASPV1kxAAIBFWbt2yLmYkxN-3rQlx84AAGiUW8m3QAC_kgAAmEMyUiRLPYHFA42KDYE',
            'CAACAgIAAyEFAASPV1kxAAIBGGbt2y-q-Qk9OGDzb_JJAQl6CX5qAAI4TAACroHISK4-onx5VWQ4NgQ',
            'CAACAgIAAyEFAASPV1kxAAIBHWbt20mOAznllBttwLgappHPPqWxAAISTAAC_lvJSHW49Y0Hr2LkNgQ',
            'CAACAgIAAyEFAASPV1kxAAIBH2bt21QvykcMEfBNlFJkmLWfJXilAAJYTQACXprJSMeu21C-q0ynNgQ',
            'CAACAgIAAyEFAASPV1kxAAIBIWbt21qZB-w3L850osnGofsdcQ9sAAKmSgACFljJSISUZOdMY6UsNgQ',
            'CAACAgIAAyEFAASPV1kxAAIBI2bt22ZQ3g5TyCqLraoz0Wg0SpltAAIhWAACrO7JSBwKuWCqRa4VNgQ',
            'CAACAgIAAyEFAASPV1kxAAIBJWbt228ieN-lEGuSc0YXFX7k5wdYAAK1SQAC-MvJSMhXNHqGfKGMNgQ',
        ]
    }

    gif_kiss = [
        'CgACAgQAAxkBAAIB2WbvDlGvRZ8XUv7Jw_2kix3e6-YCAAKPBAACPJy1UbM24sSKcF1dNgQ',
        'CgACAgQAAxkBAAIB7mbvE7_lYzVV6lBwxAvkNx-FMAaLAAJyBAACvtNsU4nuemczlr8HNgQ',
        'CgACAgQAAxkBAAIB8GbvE-NbI1RR0-OX7ECLnIqltzT8AALjAwACfCA0U56LBBa911vaNgQ',
        'CgACAgQAAxkBAAIB8mbvFAKlUHwlRjvEhZC7k1VO4CW2AAICBAAClTKVU1_nu6ABr5ufNgQ',
        'CgACAgQAAxkBAAIB9GbvFBZrcZ00A7YPIAbOVTfV4oHBAAJrBQACKQ00UGNI_4vuQmq2NgQ',
        'CgACAgQAAxkBAAIB9mbvFCwdISjoYEOyNJaDuuJYQJB2AALmBAACqpJ9U2GJlf-_GILuNgQ',
        'CgACAgQAAxkBAAIB-GbvFDu4h9-G5T6sWyhO01nTg1_kAAJ0BQACn5DsU1FJo8C1QbwxNgQ',
        'CgACAgQAAxkBAAICDmbvvUrb-W_Hfw2v1g9qKwHZ7AScAAINAwACkfAFU1Jy_Va83W2QNgQ',
        'CgACAgQAAxkBAAICEGbvvV3jZ00hzHl3--apyo550-XrAAKpBQAC0T9sUk3tEPJefVrYNgQ,'
        'CgACAgQAAxkBAAICEmbvvW5z5dwn7wu7Zkc8aiHgaVSsAALeBAACAoddUfpN8roPbv-ONgQ',
        'CgACAgQAAxkBAAICFGbvvXlDUoZbr2SCRwSwxwionE5FAAJOAwACTxelUpxhg0mYdxW5NgQ',
        'CgACAgQAAxkBAAICFmbvvYqBqpBliFWZjgmNjEMkMhkpAAK-BAACn5HNUvjk-igBawW-NgQ',
        'CgACAgQAAxkBAAICGGbvvaP1b8PzGWf3DMcbWpXGItAgAAKCAwACnz3tUvU_Yu8-t4idNgQ',
        'CgACAgQAAxkBAAICGmbvvdZrAAG0U8JZsjB3xg9TzqimTgAC5AIAAldRDVNIt1TZZgaU4zYE',
        'CgACAgQAAxkBAAICHGbvveLMTYsP-U0q72xx5Lyyr2DKAALoAwACdjWUURQQeT7df-8TNgQ',
        'CgACAgQAAxkBAAICHmbvvfVzZf-Hc54d-GbmrYsLwPocAALQAwACvzftUKj6omiPTqopNgQ',
        'CgACAgQAAxkBAAICIGbvvhMkWccLeqvvhgO94950p4NRAAJUBgACbr3EU-C-6N67kXCLNgQ',
        'CgACAgQAAxkBAAICImbvvjg-5Dmaz8HeDx7SpMd10De_AAIxAwAC5qYEU4cHrd01vXERNgQ',
        'CgACAgQAAxkBAAICJGbvvkakx0S8fyNBjEO7WbirgoG5AAIqAwACi-ENUz3PPWZG-6AYNgQ',
        'CgACAgQAAxkBAAICJmbvvmGga8caO34o0zK1_JlXcRgbAAKZBAACyyW9Udn_Jxxt8Z5oNgQ',
        'CgACAgQAAxkBAAICKGbvvsvdC1JEylw02uy5CFLJDLyYAAJ_BQACAlpMUW73u_BMLTnbNgQ',
        'CgACAgQAAxkBAAICKmbvvuvtaD-xFkqMbCsoxRp8SPchAAK_BAACNorMUkFLkKc1EieeNgQ',
        'CgACAgQAAxkBAAICLGbvvyWK9f5uZN--QOzQVVAtdS74AAJoAwAC8zbsUfOKpRvBBre1NgQ',
        'CgACAgQAAxkBAAICLmbvv2PL3k1O_9JHcbVNyMCkfQKnAALhAgAC1O0dUz8Bo1ty2wrDNgQ',
        'CgACAgQAAxkBAAICMmbvv6rP48SH6ZrtdU-OtJt_1TYkAAI2AwACmNcsUyWTyF6jdzSDNgQ',
        'CgACAgQAAxkBAAICNGbvv8WcpVCZRmD4K8P1dhZ9qYNNAAIEAwACxZlEUwUcbYyjws89NgQ',
        'CgACAgQAAxkBAAICNmbvv-YAAbu9zMRTV-GDbPg0UH_RigAC4gIAAjHMNVNqOvIjyqW_VTYE',
        'CgACAgQAAxkBAAICOmbvwIbITfP3GFJoIsZHZi8x4fFxAALnAgACV4g1Uy6Y-HCQLyysNgQ',
        'CgACAgQAAxkBAAICPGbvwLKECC_sCbLb3tM2gwrLuTWBAAIcAwAC8e8MU3JR6vmmVunnNgQ',
        'CgACAgQAAxkBAAICPmbvwO4LAlbjOFfcquF0cEwJH7tRAALrAgACNTYNUxqFoNjNfk0UNgQ',
    ]

    gif_hugged = [
        'CgACAgQAAxkBAAIDKmbv_jjLXx5YXYjtKmw_CpTS65LaAAIcAwACOFF1U_u2aCZVgaeWNgQ',
        'CgACAgQAAxkBAAIDLGbv_kaquGObhcjDquibaoNSZFmpAALuAgAC_3Y9U3fRwIa7YaoZNgQ',
        'CgACAgQAAxkBAAIDLmbv_lGgD83gJ_Qz0vKJlHtG6mrJAALZBAACqnXsUZOXK37LSgPDNgQ',
        'CgACAgQAAxkBAAIDMGbv_ltF0d8er8VWQqBB_upwYhrqAAJgAwACfHT0Ue6J_-JcvSh9NgQ',
        'CgACAgQAAxkBAAIDMmbv_mZ7hjfELtE2A_eo3kZpToHfAAKuBQACC_89U6avTD9z5VPKNgQ',
        'CgACAgQAAxkBAAIDNGbv_nTVBhmB57ymV5wfLkEb49rUAAIQAwACC2NkU1ePl-Xqmc8AATYE',
        'CgACAgQAAxkBAAIDNmbwA-z5CsZ77KWXTms4Xv7UECVYAALoBQACou-dU--wJtl4bN-4NgQ',
        'CgACAgQAAxkBAAIDOGbwBAH_HsSVCNMiW31uiS3Sq_wNAAKCAwACesOkUpLrc8QbwwXjNgQ',
        'CgACAgQAAxkBAAIDOmbwBBX1YOG31dpLMFrSIUrDjPHQAAIsBAACuZnEUPiI9wSWj1XGNgQ',
        'CgACAgQAAxkBAAIDPmbwBIo4mKQ6mU7gF6bg25IEs5uAAAIXBgACqIdMUB0mdEJjDAd2NgQ',
        'CgACAgQAAxkBAAIDQmbwBKyYrg4vr3DyUiIt7WdJZAxLAAKLBQACCmbNUkEN_mZ6BKSpNgQ',
        'CgACAgQAAxkBAAIDRmbwBTkG6DXVGO4jMg9Pb6aMwT6YAAJPBAAC8z-NU2a-7tSohnUeNgQ',
        'CgACAgQAAxkBAAIDSGbwBVDuanzV7WljhJ84OPnaJr8FAAIaBAACFo3cU7nSEcTmLwIDNgQ',
        'CgACAgQAAxkBAAIDSmbwBWuJx5eXpAEmspcLSeYijWBHAAI9AwACdDUkU7bi2_penDVfNgQ',
        'CgACAgQAAxkBAAIDTGbwBX3x5PUgA75O6_EbmVRdZa6aAAJvAwACOmVVUuyKhdyHfYxTNgQ',
        'CgACAgQAAxkBAAIDTmbwBYtk4o-zuMz8lDKb5B8I4ILhAAItAwAC4iylU66p2LBS2SPnNgQ',
        'CgACAgQAAxkBAAIDUGbwBbEpCpmiPZrGiUIeCCuU3-RcAAI9AwACddu9U887gVbXJJdoNgQ',
        'CgACAgQAAxkBAAIDUmbwBcDjIWLm7vGjaeiBEz_KQ_pQAAJWAwACtXeEUDLHLiwKQvSKNgQ',
        'CgACAgQAAxkBAAIDVmbwBgABwU3LCRArDhZPy2PALl1gZgACPwMAAlyrHFP_KYsC0Q3pXDYE',
        'CgACAgQAAxkBAAIDXGbwBjo_XdUJBwRucoIg3Y8McGfzAAJAAwACfAzVUfLEn9-UzlQzNgQ',
        'CgACAgQAAxkBAAIDZGbwBpgfu_BsA_OlELQaAAGMHBgFXAAC_AIAAhyuDVOMTYCKqtqvVzYE',
        'CgACAgQAAxkBAAIDbGbwB5DxMLJ7gnLLK5ZbvLAV2f4FAAIHAwACc4EMUx2E6gR7g1wLNgQ',
        'CgACAgQAAxkBAAIDbmbwB7T7FPLI7U1FXNc2fnSVhDacAAK9AgACRYgMU3_7wRhMb7lrNgQ',
        'CgACAgQAAxkBAAIDc2bwCuHIPowpsj4XbMH0L7k1OPGSAALlAgAC6LJEU-4Pe1vMqRm_NgQ',
        'CgACAgQAAxkBAAIDembwC2fkxq_HCHK0Kqh1hVFWKJanAAI5AwACMHAFU7yS0uDDW9I4NgQ',
        'CgACAgQAAxkBAAIDg2bwDRbzDdviwfhEIJ1lrk_-bft7AAI9AwAC6iUFU30hcXFKNhvfNgQ',
        'CgACAgQAAxkBAAIDgWbwDOWgCvYi_FU23GNLv-OfkoRNAAL6AgACsvwkU5EF7PINU0gLNgQ',
        'CgACAgQAAxkBAAIDhWbwDTYThTZ9W8CRg-m8YkekxaVcAAKIAwAC1oG9UYIn7jbUYGtZNgQ',
        'CgACAgQAAxkBAAIDiWbwDW6u38jZEAXuKhvasthlK1WHAAI1AwACSpIMUwgDcKMUsmbINgQ',
        'CgACAgQAAxkBAAIDh2bwDWAgEp_SclWPBdBd7xCwlppPAAKtAgAC-7sNUw6C3Ee0M9qbNgQ',
    ]

    responses_liar = ['Да', 'Нет', 'Может быть', 'Возможно', 'Наверное', 'Не знаю', 'Это секрет', 'Я не знаю, но я точно не вру',
                 'Да, но только иногда', 'Вероятно', 'Скорее всего', 'Вряд ли', 'Я не уверен', 'Может, а может и нет',
                 'Это сложно сказать', 'Я не знаю его достаточно хорошо', 'Он может и не врать', 'Он может и врать',
                 'Я не могу судить', 'У меня нет достаточной информации', 'Я не хочу отвечать на этот вопрос',
                 'Это не моя проблема', 'Я не знаю, что сказать', 'Возможно, но я не уверен', 'Вероятно, но не точно',
                 'Я не могу ответить на этот вопрос', 'Это не моя забота', 'Я не знаю его мотивы']

    responses_win = ['Поздравляю, вы выиграли!', 'Удача на вашей стороне!', 'Вы победили!']

    responses_lose = ['К сожалению, вы проиграли', 'В следующий раз повезет', 'Неудача']


    def leaders_command(message):
        user_id = message.from_user.id
        with open('data.txt', 'r') as f:
            users_data = [line.strip().split('|') for line in f.readlines()]

        users_data.sort(key=lambda x: int(x[3]), reverse=True)

        leaderboard_message = f'{emoji.emojize(":trophy:")} Топ 3 пользователей\n\n'
        for i, user in enumerate(users_data[:3]):
            if i == 0:
                leaderboard_message += f'{emoji.emojize(":1st_place_medal:")} {user[1]} {user[3]}\n'
            elif i == 1:
                leaderboard_message += f'{emoji.emojize(":2nd_place_medal:")} {user[1]} {user[3]}\n'
            elif i == 2:
                leaderboard_message += f'{emoji.emojize(":3rd_place_medal:")} {user[1]} {user[3]}\n'

        user_data = next((user for user in users_data if user[0] == str(user_id)), None)
        if user_data:
            user_score = int(user_data[3])
            user_rank = sum(1 for user in users_data if int(user[3]) > user_score) + 1
            leaderboard_message += f'\n{emoji.emojize(":sports_medal:")} Твоё место {user_rank}\n{emoji.emojize(":eggplant:")} Твоя длина {user_score}'

        bot.send_message(message.chat.id, leaderboard_message, reply_to_message_id=message.message_id)


    def up_command(message):
        user_id = message.from_user.id
        user_name = message.from_user.first_name
        current_date = datetime.datetime.now(pytz.timezone('Europe/Moscow')).date()
        current_timestamp = datetime.datetime.now(pytz.timezone('Europe/Moscow')).timestamp()

        with open('data.txt', 'r+', encoding='utf-8') as f:
            f.seek(0)
            users_data = [line.strip().split('|') for line in f.readlines()]

            user_data = next((user for user in users_data if user[0] == str(user_id)), None)

            if user_data:
                # Update existing user data
                if user_data[1] != user_name:
                    user_data[1] = user_name
                stored_date = datetime.datetime.strptime(user_data[2], '%Y-%m-%d').date()
                if stored_date < current_date:
                    # Update date and timestamp
                    user_data[2] = str(current_date)
                    user_data[4] = str(current_timestamp)
                    score = int(user_data[3])
                    delta_score = random.randint(-5, 10)
                    score += delta_score
                    user_data[3] = str(score)
                else:
                    last_command_timestamp = float(user_data[4])
                    remaining_time = 86400 - (current_timestamp - last_command_timestamp)
                    hours = int(remaining_time // 3600)
                    minutes = int((remaining_time % 3600) // 60)
                    seconds = int(remaining_time % 60)
                    bot.send_message(message.chat.id,
                                     f'{emoji.emojize(":face_with_monocle:")} Ты уже пробовал сегодня увеличить член\n{emoji.emojize(":hourglass_not_done:")} Осталось ждать: {hours} час. {minutes} мин. {seconds} сек.',
                                     reply_to_message_id=message.message_id)
                    return
            else:
                # Create new user data
                score = 0
                delta_score = random.randint(-5, 10)
                score += delta_score
                user_data = [str(user_id), user_name, str(current_date), str(score), str(current_timestamp)]
                users_data.append(user_data)

            f.seek(0)
            f.truncate()
            for user in users_data:
                f.write('|'.join(user) + '\n')

            if delta_score > 0:
                bot.send_message(message.chat.id,
                                 f'{emoji.emojize(":eggplant:")} Ваш член увеличился на {delta_score} см\nТеперь у вас {score} см',
                                 reply_to_message_id=message.message_id)
            elif delta_score < 0:
                bot.send_message(message.chat.id,
                                 f'{emoji.emojize(":eggplant:")} Ваш член уменьшился на {-delta_score} см\nТеперь у вас {score} см',
                                 reply_to_message_id=message.message_id)
            else:
                bot.send_message(message.chat.id,
                                 f'{emoji.emojize(":eggplant:")} Ваш член не изменился\nУ тебя {score} см',
                                 reply_to_message_id=message.message_id)

    def get_number(message: types.Message, try_num: int, right_num: int):
        if message.text.isdigit():
            if right_num == int(message.text):
                bot.send_message(message.chat.id, f'{emoji.emojize(":party_popper:")} Вы отгадали число!', reply_to_message_id=message.message_id)
            else:
                bot.send_message(message.chat.id, f'{emoji.emojize(":pensive_face:")} Мимо! Я загадал {right_num}', reply_to_message_id=message.message_id)
        else:
            return


    @bot.message_handler(commands=['start'])
    def send_welcome(message):
        markup = telebot.types.InlineKeyboardMarkup()
        btn_url = telebot.types.InlineKeyboardButton('Поддержать автора', url='https://yoomoney.ru/bill/pay/15BOLV72SNG.240919')
        markup.add(btn_url)
        bot.reply_to(message, f"{emoji.emojize(':waving_hand:')} Привет, {message.from_user.first_name}\n{emoji.emojize(':robot:')} Это бот телеграм канала <b><a href='https://t.me/mrKuzyaLakomkin'>Кузя лакамкiн</a></b>\n{emoji.emojize(':page_with_curl:')} Ознакомься с командами /help", parse_mode="HTML", reply_markup=markup)
        user_id = message.from_user.id
        with open('ids.txt', 'r+') as f:
            ids = f.read().splitlines()
            if str(user_id) not in ids:
                f.write(str(user_id) + '\n')


    @bot.message_handler(commands=['help'])
    def send_help(message):
        help_message = f"{emoji.emojize(':information:')} Список команд бота:\n\n"
        help_message += f"{emoji.emojize(':busts_in_silhouette:')} /add - добавить бота в группу\n"
        help_message += f"{emoji.emojize(':money_with_wings:')} /donate - поддержать автора донатом\n"
        help_message += f"{emoji.emojize(':eggplant:')} @KuzyakrutoyBot увеличить - увеличить член\n"
        help_message += f"{emoji.emojize(':trophy:')} @KuzyakrutoyBot лидеры - показать лидеров\n"
        help_message += f"{emoji.emojize(':face_with_monocle:')} @KuzyakrutoyBot он врёт? - ответить на вопрос\n"
        help_message += f"{emoji.emojize(':coin:')} @KuzyakrutoyBot орёл|решка - сыграть в орла и решку\n"
        help_message += f"{emoji.emojize(':kissing_face:')} @KuzyakrutoyBot поцеловал [имя] - поцеловать кого-то\n"
        help_message += f"{emoji.emojize(':smiling_face_with_open_hands:')} @KuzyakrutoyBot обнял [имя] - обнять кого-то\n"
        help_message += f"{emoji.emojize(':white_question_mark:')} @KuzyakrutoyBot загадай число - угадать число\n"
        bot.send_message(message.chat.id, help_message, reply_to_message_id=message.message_id)


    @bot.message_handler(commands=['donate'])
    def send_donate(message):
        markup = telebot.types.InlineKeyboardMarkup()
        btn_url = telebot.types.InlineKeyboardButton('Поддержать автора', url='https://yoomoney.ru/bill/pay/15BOLV72SNG.240919')
        markup.add(btn_url)
        bot.reply_to(message, f"{emoji.emojize(':money_with_wings:')} Поддержать автора донатом", reply_markup=markup)


    @bot.message_handler(commands=['add'])
    def send_add_message(message):
        me = bot.get_me()
        bot_username = me.username
        markup = telebot.types.InlineKeyboardMarkup()
        btn_add = telebot.types.InlineKeyboardButton('Добавить бота в группу', url=f'https://t.me/{bot_username}?startgroup=start')
        markup.add(btn_add)
        bot.reply_to(message, f'{emoji.emojize(":busts_in_silhouette:")} Вы можете добавить этого бота в свою группу', reply_markup=markup)


    @bot.message_handler(commands=['privet'])
    def send_privet(message):
        bot.send_photo(message.chat.id,
                       "AgACAgIAAxkBAAMSZuqd7nvcBznStmC3bOMsW4lsH30AAo3gMRsjTVBLcO3CiMrLBacBAAMCAANtAAM2BA",
                       reply_to_message_id=message.message_id)


    @bot.message_handler(content_types=['text'])
    def handle_message(message):
        text = message.text
        if message.reply_to_message and message.reply_to_message.from_user.id == bot.get_me().id:
            if text.lower() in ['привет', 'прив', 'пр', 'ку']:
                bot.send_photo(message.chat.id, "AgACAgIAAxkBAAMSZuqd7nvcBznStmC3bOMsW4lsH30AAo3gMRsjTVBLcO3CiMrLBacBAAMCAANtAAM2BA", reply_to_message_id=message.message_id)
        elif text.lower() == '@kuzyakrutoybot увеличить':
                up_command(message)
        elif text.lower() == '@kuzyakrutoybot лидеры':
                leaders_command(message)
        elif re.match(r'@KuzyakrutoyBot\s*(он врёт|он врет)', text, re.IGNORECASE):
            response = random.choice(responses_liar)
            bot.reply_to(message, response)
            action = random.choice([True, False])
            if action:
                sticker_pack = random.choice(list(sticker_packs.keys()))
                sticker_id = random.choice(sticker_packs[sticker_pack])
                bot.send_sticker(message.chat.id, sticker_id, reply_to_message_id=message.message_id)
        elif re.match(r'@KuzyakrutoyBot\s*(орёл|орел|решка|решку)', text, re.IGNORECASE):
            user_choice = re.search(r'(орёл|орел|решка|решку)', text, re.IGNORECASE).group(0).lower()
            if user_choice in ['орёл', 'орел']:
                user_choice = 'орёл'
            else:
                user_choice = 'решка'
            bot_choice = random.choice(['орёл', 'решка'])
            temp_response = bot.reply_to(message, f'{emoji.emojize(":coin:")}')
            time.sleep(2.5)
            if user_choice == bot_choice:
                response = f'Выпало: {bot_choice}\n{emoji.emojize(":green_square:")} {random.choice(responses_win)} {emoji.emojize(":green_square:")}'
            else:
                response = f'Выпало: {bot_choice}\n{emoji.emojize(":red_square:")} {random.choice(responses_lose)} {emoji.emojize(":red_square:")}'
            bot.edit_message_text(response, message.chat.id, temp_response.message_id)
        elif text.startswith('@KuzyakrutoyBot поцеловал'):
            username = message.from_user.first_name
            kiss_text = text.replace('@KuzyakrutoyBot поцеловал', '').strip()
            if not kiss_text:
                bot.reply_to(message, "Укажите кого вы поцеловали!", parse_mode="Markdown")
            else:
                random_gif_id = random.choice(gif_kiss)
                bot.send_animation(message.chat.id, random_gif_id, reply_to_message_id=message.message_id, caption=f"<b>{username}</b> поцеловал <b>{kiss_text}</b>", parse_mode="HTML")
        elif text.startswith('@KuzyakrutoyBot обнял'):
            username = message.from_user.first_name
            hugged_text = text.replace('@KuzyakrutoyBot обнял', '').strip()
            if not hugged_text:
                bot.reply_to(message, "Укажите кого вы обняли!", parse_mode="Markdown")
            else:
                random_gif_id = random.choice(gif_hugged)
                bot.send_animation(message.chat.id, random_gif_id, reply_to_message_id=message.message_id, caption=f"<b>{username}</b> обнял <b>{hugged_text}</b>", parse_mode="HTML")
        elif text.startswith('@KuzyakrutoyBot загадай число'):
            rnumber = random.randint(0, 10)
            bot.send_message(message.chat.id, f'{emoji.emojize(":white_question_mark:")} Отгадайте число от 0 до 10, у вас 1 попытка', parse_mode="HTML", reply_to_message_id=message.message_id)
            bot.register_next_step_handler(message, get_number, 1, rnumber)


    bot.infinity_polling()
except Exception as e:
    logger.error(f"Error in main code: {e}")
