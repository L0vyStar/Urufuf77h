import telebot
import qrcode
from PIL import Image
from pyzbar.pyzbar import decode
import io
import uuid
import os
import emoji

TEMP_DIR = "temp"
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

bot = telebot.TeleBot('7659436543:AAEQpLHZFpcecx3-7y9R9mWNjsVqzq1syU0')

def save_user_id(user_id):
    with open('id.txt', 'a+') as file:
        file.seek(0)
        ids = file.read().splitlines()
        if str(user_id) not in ids:
            file.write(f"{user_id}\n")
            return True
    return False

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, f"{emoji.emojize(':waving_hand:')} Отправьте текст для создания QR-кода или изображение с QR-кодом для распознавания")
    user_id = message.from_user.id
    save_user_id(user_id)

@bot.message_handler(content_types=['text'])
def generate_qr(message):
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(message.text)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    unique_filename = f'qr_{uuid.uuid4()}.png'
    file_path = os.path.join(TEMP_DIR, unique_filename)

    img.save(file_path)

    with open(file_path, 'rb') as photo:
        bot.send_photo(message.chat.id, photo, caption="QR-код создан с помощью @EasyQRCodeBot", reply_to_message_id=message.message_id)

    os.remove(file_path)

@bot.message_handler(content_types=['photo'])
def scan_qr(message):
    file_info = bot.get_file(message.photo[-1].file_id)
    downloaded_file = bot.download_file(file_info.file_path)

    temp_file_name = f'temp_{uuid.uuid4()}.png'
    temp_file_path = os.path.join(TEMP_DIR, temp_file_name)
    
    with open(temp_file_path, 'wb') as new_file:
        new_file.write(downloaded_file)
    
    image = Image.open(temp_file_path)
    decoded_objects = decode(image)
    
    if decoded_objects:
        for obj in decoded_objects:
            bot.reply_to(message, f"Содержимое QR-кода: {obj.data.decode('utf-8')}")
    else:
        bot.reply_to(message, f"{emoji.emojize(':cross_mark:')} QR-код не найден на изображении")

    os.remove(temp_file_path)

try:
    bot.polling(none_stop=True)
except Exception as e:
    print(e)